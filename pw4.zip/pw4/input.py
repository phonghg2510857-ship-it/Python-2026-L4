import math
import curses
from domains import Student, Course

def ask(stdscr, text):
    curses.echo()
    stdscr.clear()
    stdscr.addstr(1, 2, text)
    stdscr.refresh()
    res = stdscr.getstr(2, 2).decode('utf-8').strip()
    curses.noecho()
    return res

def input_courses(stdscr, system):
    num = int(ask(stdscr, "Enter number of courses: "))
    for _ in range(num):
        c_id = ask(stdscr, "Enter course ID: ")
        c_name = ask(stdscr, "Enter course name: ")
        credits = float(ask(stdscr, "Enter credits: "))
        system.courses.append(Course(c_id, c_name, credits))

def input_students(stdscr, system):
    num = int(ask(stdscr, "Enter number of students: "))
    for _ in range(num):
        s_id = ask(stdscr, "Enter student ID: ")
        s_name = ask(stdscr, "Enter student name: ")
        dob = ask(stdscr, "Enter DoB: ")
        system.students.append(Student(s_id, s_name, dob))

def input_marks(stdscr, system):
    if not system.courses or not system.students:
        ask(stdscr, "Add courses and students first! (Press Enter)")
        return

    c_id = ask(stdscr, "Enter course ID to input marks: ")
    course = system.get_course_by_id(c_id)
    if not course:
        ask(stdscr, "Invalid course ID! (Press Enter)")
        return

    for s in system.students:
        raw_mark = float(ask(stdscr, f"Enter mark for {s.name} ({s.id}): "))
        s.marks[c_id] = math.floor(raw_mark * 10.0) / 10.0