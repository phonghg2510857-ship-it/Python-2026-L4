from .student import Student
from .course import Course
from .mark_system import SchoolSystem