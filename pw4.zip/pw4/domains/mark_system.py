class SchoolSystem:
    def __init__(self):
        self.students = []
        self.courses = []

    def get_course_by_id(self, course_id):
        for c in self.courses:
            if c.id == course_id:
                return c
        return None

    def get_sorted_students(self):
        for s in self.students:
            s.calculate_gpa(self.courses)
        return sorted(self.students, key=lambda s: s.gpa, reverse=True)