import numpy as np

class Student:
    def __init__(self, student_id, name, dob):
        self.id = student_id
        self.name = name
        self.dob = dob
        self.marks = {}
        self.gpa = 0.0

    def calculate_gpa(self, courses):
        c_list, m_list = [], []
        for course in courses:
            if course.id in self.marks:
                c_list.append(course.credits)
                m_list.append(self.marks[course.id])

        if not c_list:
            self.gpa = 0.0
            return 0.0

        c_arr = np.array(c_list)
        m_arr = np.array(m_list)
        self.gpa = float(np.sum(c_arr * m_arr) / np.sum(c_arr))
        return self.gpa