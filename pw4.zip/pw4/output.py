import curses
from input import ask

def list_courses(stdscr, system):
    stdscr.clear()
    stdscr.addstr(1, 2, "--- COURSES ---", curses.A_BOLD)
    row = 3
    for c in system.courses:
        stdscr.addstr(row, 2, f"ID: {c.id} | Name: {c.name} | Credits: {c.credits}")
        row += 1
    ask(stdscr, "\nPress Enter to return...")

def list_students_sorted(stdscr, system):
    stdscr.clear()
    stdscr.addstr(1, 2, "--- STUDENTS (SORTED BY GPA) ---", curses.A_BOLD)
    
    sorted_students = system.get_sorted_students()
    row = 3
    for s in sorted_students:
        stdscr.addstr(row, 2, f"ID: {s.id} | Name: {s.name} | DoB: {s.dob} | GPA: {s.gpa:.2f}")
        row += 1
    ask(stdscr, "\nPress Enter to return...")

def show_marks(stdscr, system):
    if not system.courses:
        ask(stdscr, "No courses available! (Press Enter)")
        return

    c_id = ask(stdscr, "Enter course ID to view marks: ")
    stdscr.clear()
    stdscr.addstr(1, 2, f"--- MARKS FOR COURSE {c_id} ---", curses.A_BOLD)
    
    row = 3
    for s in system.students:
        if c_id in s.marks:
            stdscr.addstr(row, 2, f"{s.name} ({s.id}): {s.marks[c_id]}")
            row += 1
    ask(stdscr, "\nPress Enter to return...")