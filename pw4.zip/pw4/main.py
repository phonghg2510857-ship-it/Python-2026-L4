import curses
from domains import SchoolSystem
from input import input_courses, input_students, input_marks
from output import list_courses, list_students_sorted, show_marks

def main(stdscr):
    curses.curs_set(0)
    system = SchoolSystem()

    while True:
        stdscr.clear()
        
        # Check window size to avoid drawing out-of-bounds
        max_y, max_x = stdscr.getmaxyx()
        if max_y < 12 or max_x < 30:
            stdscr.addstr(0, 0, "Please enlarge terminal window!")
            stdscr.refresh()
            choice = stdscr.getkey()
            continue

        try:
            stdscr.addstr(1, 2, "=== STUDENT SYSTEM ===", curses.A_BOLD)
            stdscr.addstr(3, 2, "1. Input Courses")
            stdscr.addstr(4, 2, "2. Input Students")
            stdscr.addstr(5, 2, "3. Input Marks")
            stdscr.addstr(6, 2, "4. List Courses")
            stdscr.addstr(7, 2, "5. List Students (By GPA)")
            stdscr.addstr(8, 2, "6. Show Marks")
            stdscr.addstr(9, 2, "7. Exit")
            stdscr.addstr(11, 2, "Choice (1-7): ")
            stdscr.refresh()
        except curses.error:
            pass

        choice = stdscr.getkey()

        if choice == '1': input_courses(stdscr, system)
        elif choice == '2': input_students(stdscr, system)
        elif choice == '3': input_marks(stdscr, system)
        elif choice == '4': list_courses(stdscr, system)
        elif choice == '5': list_students_sorted(stdscr, system)
        elif choice == '6': show_marks(stdscr, system)
        elif choice == '7': break

if __name__ == "__main__":
    curses.wrapper(main)